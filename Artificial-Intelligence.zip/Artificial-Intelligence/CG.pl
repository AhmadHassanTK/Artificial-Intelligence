:- include('KB.pl').


goal(S):-
        ids(S,1).


ids(X,L):-
        (call_with_depth_limit(goal2(X),L,R), number(R));
        (call_with_depth_limit(goal2(X),L,R), R=depth_limit_exceeded,
        L1 is L+1, ids(X,L1)).



goal2(result(A, R)):-
  station(X,Y),
  ships_loc(ShipList),
  goal2helper(agent(X,Y),0,ShipList,result(A, R)).


goal2helper(agent(X,Y),0,[],firstaction):-
  agent_loc(X, Y).

goal2helper(agent(X,Y),NOP,ShipsList,result(A, R)):-
  (X1 is X+1,
   grid(W, H),
   checkpositionV(X1,Y,W,H),
   A=up,
   goal2helper(agent(X1,Y),NOP,ShipsList,R));
  (X1 is X-1,
   grid(W, H),
   checkpositionV(X1,Y,W,H),
   A=down,
   goal2helper(agent(X1,Y),NOP,ShipsList,R));
  (Y1 is Y-1,
   grid(W, H),
   checkpositionV(X,Y1,W,H),
   A=right,
   goal2helper(agent(X,Y1),NOP,ShipsList,R));
  (Y1 is Y+1,
   grid(W, H),
   checkpositionV(X,Y1,W,H),
   A=left,
   goal2helper(agent(X,Y1),NOP,ShipsList,R));
  (station(X, Y),
   capacity(C),
   A=drop,
   goal2helper(agent(X,Y),C,ShipsList,R));
  (NOP > 0,
   pickupfromship(ShipsList,X,Y,ShipsList2),
   NOP2 is NOP - 1,
   A=pickup,
   goal2helper(agent(X,Y),NOP2,ShipsList2,R)).

pickupfromship(SList,X,Y,SList2):-
  delete(SList,[X,Y],SList2).

checkpositionV(X, Y,W,H):-
  X>=0,
  X<H,
  Y>=0,
  Y<W.














































